from mongita import MongitaClientDisk
import os
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
client = MongitaClientDisk(os.path.join(BASE_DIR, "mongita_data"))

db = client.bookstore

categories_col = db.category
books_col = db.book

# Reset collections
categories_col.delete_many({})
books_col.delete_many({})

# -----------------------------
# CATEGORIES
# -----------------------------
categories = [
    {"categoryId": 1, "categoryName": "Architecture", "categoryImage": "architecture-category.jpg"},
    {"categoryId": 2, "categoryName": "Law",          "categoryImage": "law-category.jpg"},
    {"categoryId": 3, "categoryName": "Mathematics",  "categoryImage": "mathematics-category.jpg"},
    {"categoryId": 4, "categoryName": "Data Science", "categoryImage": "data-science-category.jpg"},
]
categories_col.insert_many(categories)
# -----------------------------
# BOOKS
# -----------------------------
books = [
    {"bookId": 1,  "categoryId": 1, "categoryName": "Architecture", "title": "Architecture: Form, Space, and Order",        "author": "Francis D.K. Ching",    "isbn": "9781118745083", "price": 59.99, "image": "ching-form.jpg",            "readNow": 1},
    {"bookId": 2,  "categoryId": 1, "categoryName": "Architecture", "title": "A Pattern Language",                          "author": "Christopher Alexander",  "isbn": "9780195019193", "price": 79.99, "image": "pattern-language.jpg",      "readNow": 0},
    {"bookId": 3,  "categoryId": 1, "categoryName": "Architecture", "title": "The Architecture of Happiness",               "author": "Alain de Botton",        "isbn": "9780375725371", "price": 24.99, "image": "architecture-happiness.jpg", "readNow": 0},
    {"bookId": 4,  "categoryId": 1, "categoryName": "Architecture", "title": "Architectural Graphics",                      "author": "Francis D.K. Ching",    "isbn": "9781118012055", "price": 44.99, "image": "arch-graphics.jpg",          "readNow": 1},
    {"bookId": 5,  "categoryId": 2, "categoryName": "Law",          "title": "Getting to Yes",                              "author": "Roger Fisher",           "isbn": "9780143118756", "price": 18.99, "image": "getting-to-yes.jpg",         "readNow": 1},
    {"bookId": 6,  "categoryId": 2, "categoryName": "Law",          "title": "The Common Law",                              "author": "Oliver Wendell Holmes",  "isbn": "9781614271765", "price": 22.99, "image": "common-law.jpg",             "readNow": 0},
    {"bookId": 7,  "categoryId": 2, "categoryName": "Law",          "title": "Law 101",                                     "author": "Jay Feinman",            "isbn": "9780190495480", "price": 21.99, "image": "law-101.jpg",                "readNow": 1},
    {"bookId": 8,  "categoryId": 2, "categoryName": "Law",          "title": "Black's Law Dictionary",                     "author": "Bryan A. Garner",        "isbn": "9781539229759", "price": 49.99, "image": "blacks-law.jpg",             "readNow": 0},
    {"bookId": 9,  "categoryId": 3, "categoryName": "Mathematics",  "title": "Calculus: Early Transcendentals",             "author": "James Stewart",          "isbn": "9781285741550", "price": 89.99, "image": "stewart-calculus.jpg",       "readNow": 1},
    {"bookId": 10, "categoryId": 3, "categoryName": "Mathematics",  "title": "Linear Algebra and Its Applications",         "author": "David C. Lay",           "isbn": "9780321982384", "price": 79.99, "image": "linear-algebra.jpg",         "readNow": 0},
    {"bookId": 11, "categoryId": 3, "categoryName": "Mathematics",  "title": "Introduction to Probability",                 "author": "Dimitri Bertsekas",      "isbn": "9781886529236", "price": 74.99, "image": "probability.jpg",            "readNow": 0},
    {"bookId": 12, "categoryId": 3, "categoryName": "Mathematics",  "title": "Discrete Mathematics and Its Applications",   "author": "Kenneth Rosen",          "isbn": "9780073383095", "price": 84.99, "image": "discrete-math.jpg",          "readNow": 1},
    {"bookId": 13, "categoryId": 4, "categoryName": "Data Science", "title": "Python for Data Analysis",                   "author": "Wes McKinney",           "isbn": "9781491957660", "price": 54.99, "image": "python-data.jpg",            "readNow": 1},
    {"bookId": 14, "categoryId": 4, "categoryName": "Data Science", "title": "The Elements of Statistical Learning",       "author": "Trevor Hastie",          "isbn": "9780387848570", "price": 89.99, "image": "esl.jpg",                    "readNow": 0},
    {"bookId": 15, "categoryId": 4, "categoryName": "Data Science", "title": "Hands-On Machine Learning",                  "author": "Aurelien Geron",         "isbn": "9781492032649", "price": 74.99, "image": "homl.jpg",                   "readNow": 1},
    {"bookId": 16, "categoryId": 4, "categoryName": "Data Science", "title": "Data Science from Scratch",                  "author": "Joel Grus",              "isbn": "9781492041139", "price": 49.99, "image": "ds-scratch.jpg",             "readNow": 0},
]
books_col.insert_many(books)
 
print("Mongita DB seeded with bookstore data.")
 
json.dump(categories, open(os.path.join(BASE_DIR, "categories.json"), "w"), indent=2)
json.dump(books,      open(os.path.join(BASE_DIR, "books.json"),      "w"), indent=2)
 
print("categories.json and books.json exported.")
